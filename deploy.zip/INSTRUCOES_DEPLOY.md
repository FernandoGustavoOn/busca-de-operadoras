# 🚀 INSTRUÇÕES FINAIS PARA DEPLOY NO RENDER.COM

## ✅ PROJETO PRONTO PARA DEPLOY!

Todos os arquivos foram preparados e estão na pasta `deploy/`:

### 📁 Arquivos Incluídos:
- ✅ `app.py` - Backend Flask otimizado
- ✅ `relatorio_cadop.csv` - Dados das operadoras
- ✅ `dist/` - Frontend buildado (Vue.js)
- ✅ `requirements.txt` - Dependências Python
- ✅ `Procfile` - Comando de start
- ✅ `render.yaml` - Configuração do Render

## 🚀 DEPLOY NO RENDER.COM (5 MINUTOS)

### 1. Acesse o Render.com
- Vá para: https://render.com
- Crie uma conta ou faça login

### 2. Criar Novo Serviço
- Clique em **"New +"**
- Selecione **"Web Service"**

### 3. Configuração do Serviço

**Opção A - Upload Manual:**
- Selecione **"Upload files"**
- Faça upload da pasta `deploy/` inteira
- Ou compacte em ZIP e faça upload

**Opção B - Repositório Git:**
- Conecte seu repositório GitHub
- Configure o diretório raiz como `deploy/`

### 4. Configurações do Serviço
- **Name**: `busca-operadoras` (ou qualquer nome)
- **Environment**: `Python 3`
- **Build Command**: `pip install -r requirements.txt`
- **Start Command**: `python app.py`
- **Plan**: `Free`

### 5. Deploy
- Clique em **"Create Web Service"**
- Aguarde 2-5 minutos para o build
- Sua aplicação estará disponível em: `https://seu-app.onrender.com`

## 🔧 CONFIGURAÇÕES AVANÇADAS (Opcional)

### Variáveis de Ambiente:
```
PYTHON_VERSION=3.11.0
FLASK_ENV=production
```

### Domínio Personalizado:
- Vá em Settings → Custom Domains
- Adicione seu domínio

## 🐛 SOLUÇÃO DE PROBLEMAS

### Erro: "Module not found"
- Verifique se `requirements.txt` está correto
- Execute: `pip install -r requirements.txt` localmente

### Erro: "Port already in use"
- O Render define a porta automaticamente
- O código já está configurado corretamente

### Frontend não carrega
- Verifique se a pasta `dist/` foi incluída
- Confirme se o Flask está servindo arquivos estáticos

### Build falha
- Verifique se todas as dependências estão no `requirements.txt`
- Confirme se o Python 3.11 está selecionado

## 📊 MONITORAMENTO

- **Logs**: Disponível no dashboard do Render
- **Métricas**: CPU, RAM, requests
- **Uptime**: Monitoramento automático

## 💰 CUSTOS

- **Plano Free**: 750 horas/mês
- **Limitação**: App "dorme" após 15min de inatividade
- **Upgrade**: $7/mês para plano pago (sempre ativo)

## 🎉 RESULTADO FINAL

Após o deploy, você terá:
- ✅ API funcionando em produção
- ✅ Frontend acessível via web
- ✅ Busca de operadoras funcionando
- ✅ Interface responsiva
- ✅ Dados atualizados da ANS

**URL da aplicação**: `https://seu-app.onrender.com`

---

## 📞 SUPORTE

Se tiver problemas:
1. Verifique os logs no dashboard do Render
2. Confirme se todos os arquivos foram enviados
3. Teste localmente primeiro: `python app.py`
4. Verifique se o Node.js foi usado para build do frontend

**🎯 Seu projeto está 100% pronto para produção!**
